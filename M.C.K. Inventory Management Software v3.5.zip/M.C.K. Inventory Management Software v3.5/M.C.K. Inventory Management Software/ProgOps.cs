﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace M.C.K.Inventory_Management_Software
{
    class ProgOps
    {
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=INEW2330fa20;" + "User Id=group2fa202330;password=1867186";
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);

        private static SqlCommand _sqlDatabaseCommand;
        private static SqlDataAdapter _daDatabase = new SqlDataAdapter();
        private static DataTable _dtDatabaseTable = new DataTable();

        private static SqlCommand _sqlCustomersCommand;
        private static SqlDataAdapter _daCustomers = new SqlDataAdapter();
        private static DataTable _dtCustomersTable = new DataTable();

        private static SqlCommand _sqlOrdersCommand;
        private static SqlDataAdapter _daOrders = new SqlDataAdapter();
        private static DataTable _dtOrdersTable = new DataTable();

        private static SqlCommand _sqlEmployeesCommand;
        private static SqlDataAdapter _daEmployees = new SqlDataAdapter();
        private static DataTable _dtEmployeesTable = new DataTable();

        private static SqlCommand _sqlSuppliersCommand;
        private static SqlDataAdapter _daSuppliers = new SqlDataAdapter();
        private static DataTable _dtSuppliersTable = new DataTable();

        private static SqlCommand _sqlProductsCommand;
        private static SqlDataAdapter _daProducts = new SqlDataAdapter();
        private static DataTable _dtProductsTable = new DataTable();

        private static StringBuilder errorMessages = new StringBuilder();

        public static DataTable DTDatabaseTable
        {
            get { return _dtDatabaseTable; }
            set { _dtDatabaseTable = value; }
        }

        public static DataTable DTCustomersTable
        {
            get { return _dtCustomersTable; }
        }

        public static DataTable DTOrdersTable
        {
            get { return _dtOrdersTable; }
            set { _dtOrdersTable = value; }
        }

        public static DataTable DTEmployeesTable
        {
            get { return _dtEmployeesTable; }
        }

        public static DataTable DTSuppliersTable
        {
            get { return _dtSuppliersTable; }
        }

        public static DataTable DTProductsTable
        {
            get { return _dtProductsTable; }
            set { _dtProductsTable = value; }
        }

        public static void OpenDatabase()
        {
            try
            {
                _cntDatabase.Open();
                MessageBox.Show("Connection to database was successfull", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public static void CloseDatabase()
        {
            try
            {
                _cntDatabase.Close();
                _cntDatabase.Dispose();
                MessageBox.Show("Connection to database was successfully closed", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public static void DatabaseDGVCommand(DataGridView dgvTables)
        {
            _sqlDatabaseCommand = null;
            _daDatabase = new SqlDataAdapter();
            _dtDatabaseTable = new DataTable();
            try
            {
                _sqlDatabaseCommand = new SqlCommand("Select * from Customers", _cntDatabase);
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                _daDatabase.Fill(_dtDatabaseTable);
                dgvTables.DataSource = _dtDatabaseTable;
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            _sqlDatabaseCommand.Dispose();
            _daDatabase.Dispose();
            _dtDatabaseTable.Dispose();
        }

        public static void DatabaseCustomersDGVCommand(DataGridView dgvTables)
        {
            _sqlCustomersCommand = null;
            _daCustomers = new SqlDataAdapter();
            _dtCustomersTable = new DataTable();
            try
            {
                _sqlCustomersCommand = new SqlCommand("Select * from Customers", _cntDatabase);
                _daCustomers.SelectCommand = _sqlCustomersCommand;
                _daCustomers.Fill(_dtCustomersTable);
                dgvTables.DataSource = _dtCustomersTable;
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            _sqlCustomersCommand.Dispose();
            _daCustomers.Dispose();
            _dtCustomersTable.Dispose();
        }

        public static void DatabaseOrdersDGVCommand(DataGridView dgvTables)
        {
            _sqlOrdersCommand = null;
            _daOrders = new SqlDataAdapter();
            _dtOrdersTable = new DataTable();
            try
            {
                _sqlOrdersCommand = new SqlCommand("Select * from Orders", _cntDatabase);
                _daOrders.SelectCommand = _sqlOrdersCommand;
                _daOrders.Fill(_dtOrdersTable);
                dgvTables.DataSource = _dtOrdersTable;
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            _sqlOrdersCommand.Dispose();
            _daOrders.Dispose();
            _dtOrdersTable.Dispose();
        }

        public static void DatabaseEmployeesDGVCommand(DataGridView dgvTables)
        {
            _sqlEmployeesCommand = null;
            _daEmployees = new SqlDataAdapter();
            _dtEmployeesTable = new DataTable();
            try
            {
                _sqlEmployeesCommand = new SqlCommand("Select * from Employees", _cntDatabase);
                _daEmployees.SelectCommand = _sqlEmployeesCommand;
                _daEmployees.Fill(_dtEmployeesTable);
                dgvTables.DataSource = _dtEmployeesTable;
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            _sqlEmployeesCommand.Dispose();
            _daEmployees.Dispose();
            _dtEmployeesTable.Dispose();
        }

        public static void DatabaseSuppliersDGVCommand(DataGridView dgvTables)
        {
            _sqlSuppliersCommand = null;
            _daSuppliers = new SqlDataAdapter();
            _dtSuppliersTable = new DataTable();
            try
            {
                _sqlSuppliersCommand = new SqlCommand("Select * from Suppliers", _cntDatabase);
                _daSuppliers.SelectCommand = _sqlSuppliersCommand;
                _daSuppliers.Fill(_dtSuppliersTable);
                dgvTables.DataSource = _dtSuppliersTable;
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            _sqlSuppliersCommand.Dispose();
            _daSuppliers.Dispose();
            _dtSuppliersTable.Dispose();
        }

        public static void DatabaseProductsDGVCommand(DataGridView dgvTables)
        {
            _sqlProductsCommand = null;
            _daProducts = new SqlDataAdapter();
            _dtProductsTable = new DataTable();
            try
            {
                _sqlProductsCommand = new SqlCommand("Select * from Products", _cntDatabase);
                _daProducts.SelectCommand = _sqlProductsCommand;
                _daProducts.Fill(_dtProductsTable);
                dgvTables.DataSource = _dtProductsTable;
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            _sqlProductsCommand.Dispose();
            _daProducts.Dispose();
            _dtProductsTable.Dispose();
        }

        public static void DatabaseTBXCommand(TextBox tbxProductID, TextBox tbxProductName, TextBox tbxAmountInStock, TextBox tbxOrderID, TextBox tbxOrderAmount, TextBox tbxEmployeeID, TextBox tbxCustomerID, TextBox tbxSupplierID)
        {
            try
            {
                string sqlStatement = "Select * From Orders o Join Suppliers s On o.SupplierID = s.SupplierID Join Products p On s.SupplierID = p.SupplierID";
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                _daDatabase.Fill(_dtDatabaseTable);
                tbxProductID.DataBindings.Add("Text", _dtDatabaseTable, "p.ProductID");
                tbxProductName.DataBindings.Add("Text", _dtDatabaseTable, "p.ProductName");
                tbxAmountInStock.DataBindings.Add("Text", _dtDatabaseTable, "p.AmountInStock");
                tbxOrderID.DataBindings.Add("Text", _dtDatabaseTable, "o.OrderID");
                tbxOrderAmount.DataBindings.Add("Text", _dtDatabaseTable, "o.OrderAmount");
                tbxEmployeeID.DataBindings.Add("Text", _dtDatabaseTable, "o.EmployeeID");
                tbxCustomerID.DataBindings.Add("Text", _dtDatabaseTable, "o.CustomerID");
                tbxSupplierID.DataBindings.Add("Text", _dtDatabaseTable, "s.SupplierID");

            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on DatabaseCommand", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on DatabaseCommand", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public static void CloseDisposeTBXData()
        {
            try
            {
                _cntDatabase.Close();
                MessageBox.Show("Connection to database was successfully closed.", "Database Connection",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                _cntDatabase.Dispose();
                _sqlDatabaseCommand.Dispose();
                _daDatabase.Dispose();
                _dtDatabaseTable.Dispose();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Close", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Close", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public static void UpdateTBXOnClose()
        {
            try
            {
                SqlCommandBuilder AdapterCommands = new SqlCommandBuilder(_daDatabase);
                _daDatabase.Update(_dtDatabaseTable);
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on UpdateOnClose", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on UpdateOnClose", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public static void DatabaseProductsTBXCommand(TextBox tbxProductID, TextBox tbxProductName, TextBox tbxAmountInStock, TextBox tbxSupplierID)
        {
            try
            {
                string sqlStatement = "Select * From Products";
                _sqlProductsCommand = new SqlCommand(sqlStatement, _cntDatabase);
                _daProducts.SelectCommand = _sqlProductsCommand;
                _daProducts.Fill(_dtProductsTable);
                tbxProductID.DataBindings.Add("Text", _dtProductsTable, "ProductID");
                tbxProductName.DataBindings.Add("Text", _dtProductsTable, "ProductName");
                tbxAmountInStock.DataBindings.Add("Text", _dtProductsTable, "AmountInStock");
                tbxSupplierID.DataBindings.Add("Text", _dtProductsTable, "SupplierID");
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on DatabaseCommand", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on DatabaseCommand", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public static void CloseDisposeProductsTBXData()
        {
            try
            {
                _cntDatabase.Close();
                MessageBox.Show("Connection to database was successfully closed.", "Database Connection", MessageBoxButtons.OK, MessageBoxIcon.Information);
                _cntDatabase.Dispose();
                _sqlProductsCommand.Dispose();
                _daProducts.Dispose();
                _dtProductsTable.Dispose();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Close", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Close", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public static void UpdateProductsTBXOnClose()
        {
            try
            {
                SqlCommandBuilder AdapterCommands = new SqlCommandBuilder(_daProducts);
                _daProducts.Update(_dtProductsTable);
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on UpdateOnClose", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on UpdateOnClose", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public static void DatabaseOrdersTBXCommand(TextBox tbxOrderID, TextBox tbxOrderAmount, TextBox tbxEmployeeID, TextBox tbxCustomerID, TextBox tbxSupplierID)
        {
            try
            {
                string sqlStatement = "Select * From Orders";
                _sqlOrdersCommand = new SqlCommand(sqlStatement, _cntDatabase);
                _daOrders.SelectCommand = _sqlOrdersCommand;
                _daOrders.Fill(_dtOrdersTable);
                tbxOrderID.DataBindings.Add("Text", _dtOrdersTable, "OrderID");
                tbxOrderAmount.DataBindings.Add("Text", _dtOrdersTable, "OrderAmount");
                tbxEmployeeID.DataBindings.Add("Text", _dtOrdersTable, "EmployeeID");
                tbxCustomerID.DataBindings.Add("Text", _dtOrdersTable, "CustomerID");
                tbxSupplierID.DataBindings.Add("Text", _dtOrdersTable, "SupplierID");
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on DatabaseCommand", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on DatabaseCommand", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public static void CloseDisposeOrdersTBXData()
        {
            try
            {
                _cntDatabase.Close();
                MessageBox.Show("Connection to database was successfully closed.", "Database Connection",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                _cntDatabase.Dispose();
                _sqlOrdersCommand.Dispose();
                _daOrders.Dispose();
                _dtOrdersTable.Dispose();
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on Close", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on Close", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public static void UpdateOrdersTBXOnClose()
        {
            try
            {
                SqlCommandBuilder AdapterCommands = new SqlCommandBuilder(_daOrders);
                _daOrders.Update(_dtOrdersTable);
            }
            catch (SqlException ex)
            {
                if (ex is SqlException)
                {
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }
                    MessageBox.Show(errorMessages.ToString(), "Error on UpdateOnClose", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show(ex.Message, "Error on UpdateOnClose", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
