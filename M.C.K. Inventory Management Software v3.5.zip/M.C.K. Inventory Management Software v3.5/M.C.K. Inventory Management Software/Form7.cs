﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace M.C.K.Inventory_Management_Software
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void btnCalculator_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f8 = new Form8();
            f8.ShowDialog();
            this.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseProductsDGVCommand(dataGridView1);
            ProgOps.DatabaseOrdersDGVCommand(dataGridView2);
        }

        private void Form7_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Data will go here.
        }
    }
}
