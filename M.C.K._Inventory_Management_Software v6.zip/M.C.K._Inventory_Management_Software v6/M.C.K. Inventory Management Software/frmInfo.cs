﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

// Programers: Miriam Lira, Chris Howell, Kevin Hack
// Instructor: Kathryn Wilganowski
// Project: M.C.K. Inventory Managment Software
// Course: Comp Software Proj: Plan/Desig (INEW-2330-50Z1)

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmInfo : Form
    {
        public frmInfo()
        {
            InitializeComponent();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmProducts products = new frmProducts();
            products.ShowDialog();
            this.Show();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmOrders orders = new frmOrders();
            orders.ShowDialog();
            this.Show();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmInventory inventory = new frmInventory();
            inventory.ShowDialog();
            this.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            CrystalReports.crptProducts products = new CrystalReports.crptProducts();
            products.SetDatabaseLogon("group2fa202330", "1867186");
            this.Hide();
            frmPrint print = new frmPrint();
            print.crvViewer.ReportSource = null;
            print.crvViewer.ReportSource = products;
            print.ShowDialog();
            this.Show();
        }

        private void frmInfo_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseDGVCommand(dgvDatabase);
        }
    }
}
