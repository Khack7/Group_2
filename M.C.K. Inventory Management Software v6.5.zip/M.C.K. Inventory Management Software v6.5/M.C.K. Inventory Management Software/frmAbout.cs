﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Programers: Miriam Lira, Chris Howell, Kevin Hack
// Instructor: Kathryn Wilganowski
// Project: M.C.K. Inventory Managment Software
// Course: Comp Software Proj: Plan/Desig (INEW-2330-50Z1)

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmAbout : Form
    {
        public frmAbout()
        {
            InitializeComponent();
        }
    }
}
