﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Media;
using Microsoft.VisualBasic;

// Programers: Miriam Lira, Chris Howell, Kevin Hack (Group_2)
// Instructor: Kathryn Wilganowski
// Project: M.C.K. Inventory Managment Software
// Course: Comp Software Proj: Plan/Desig (INEW-2330-50Z1)

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmProducts : Form
    {
        string myState;
        int myBookmark;

        public frmProducts()
        {
            InitializeComponent();
        }

        CurrencyManager productsManager;

        private void btnCalculator_Click(object sender, EventArgs e)
        {
            frmCalculator calc = new frmCalculator();
            calc.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseProductsTBXCommand(tbxProductID, tbxProductName, tbxAmountInStock, tbxSupplier);
            productsManager = (CurrencyManager)BindingContext[ProgOps.DTProductsTable];
            SetState("Veiw");
        }

        private void frmProducts_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (myState.Equals("Edit") || myState.Equals("Add"))
            {
                MessageBox.Show("You must finish the current edit before stopping the application.", "Finish Edit!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = true;
            }
            else
            {
                ProgOps.UpdateProductsTBXOnClose();
            }
        }

        private void SetState(string appState)
        {
            switch (appState)
            {
                case "Veiw":
                    tbxProductID.ReadOnly = true;
                    tbxProductName.ReadOnly = true;
                    tbxAmountInStock.ReadOnly = true;
                    tbxSupplier.ReadOnly = true;
                    btnPrev.Enabled = true;
                    btnNext.Enabled = true;
                    btnFirst.Enabled = true;
                    btnLast.Enabled = true;
                    btnAdd.Enabled = true;
                    btnSave.Enabled = false;
                    btnCancel.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = false;
                    btnCalculator.Enabled = true;
                    btnBack.Enabled = true;
                    tbxProductID.Focus();
                    break;
                case "Add":
                    tbxProductID.ReadOnly = false;
                    tbxProductName.ReadOnly = false;
                    tbxAmountInStock.ReadOnly = false;
                    tbxSupplier.ReadOnly = false;
                    btnPrev.Enabled = false;
                    btnNext.Enabled = false;
                    btnFirst.Enabled = false;
                    btnLast.Enabled = false;
                    btnAdd.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnCalculator.Enabled = true;
                    btnBack.Enabled = false;
                    tbxProductID.Focus();
                    break;
                case "Edit":
                    tbxProductID.ReadOnly = false;
                    tbxProductName.ReadOnly = false;
                    tbxAmountInStock.ReadOnly = false;
                    tbxSupplier.ReadOnly = false;
                    btnAdd.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = true;
                    btnCalculator.Enabled = true;
                    btnBack.Enabled = false;
                    tbxProductID.Focus();
                    break;
            }
            myState = appState;
            tbxProductID.Focus();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            productsManager.Position = 0;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            productsManager.Position--;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            productsManager.Position++;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            productsManager.Position = productsManager.Count - 1;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Password required to make alterations", "Input Password", "");

            List<string> passwords = new List<string>();
            passwords.Add("2424242424"); // Miriam Lira
            passwords.Add("2020002008"); // Chris Howell
            passwords.Add("4206900008"); // Kevin Hack
            passwords.Add("0123456789"); // Mrs. Wilganowski

            bool allowed = false;

            foreach (string s in passwords)
            {
                if (s == input)
                {
                    allowed = true;
                    break;
                }
            }

            if (allowed)
            {
                SetState("Edit");
            }
            else
            {
                MessageBox.Show("INVALID PASSWORD", "UNACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SetState("View");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string input = Interaction.InputBox("Password required to make alterations", "Input Password", "");

            List<string> passwords = new List<string>();
            passwords.Add("2424242424"); // Miriam Lira
            passwords.Add("2020002008"); // Chris Howell
            passwords.Add("4206900008"); // Kevin Hack
            passwords.Add("0123456789"); // Mrs. Wilganowski

            bool allowed = false;

            foreach (string s in passwords)
            {
                if (s == input)
                {
                    allowed = true;
                    break;
                }
            }

            if (allowed)
            {
                myBookmark = productsManager.Position;
                SetState("Add");
                productsManager.AddNew();
            }
            else
            {
                MessageBox.Show("INVALID PASSWORD", "UNACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SetState("View");
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            productsManager.EndCurrentEdit();
            //ProgOps.DTOrdersTable.DefaultView.Sort = "ProductID";
            MessageBox.Show("The record was saved!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            SetState("Veiw");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult response;
            response = MessageBox.Show("Are you sure you want to delete?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (response == DialogResult.Yes)
            {
                productsManager.RemoveAt(productsManager.Position);
            }
            SetState("Veiw");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            productsManager.CancelCurrentEdit();
            if (myState.Equals("Add"))
            {
                productsManager.Position = myBookmark;
            }
            MessageBox.Show("The record was cancelled!", "Cancelled");
            SetState("Veiw");
        }
    }
}
