﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmInfo : Form
    {
        public frmInfo()
        {
            InitializeComponent();
        }

        private void btnProducts_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmProducts f5 = new frmProducts();
            f5.ShowDialog();
            this.Show();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmOrders f6 = new frmOrders();
            f6.ShowDialog();
            this.Show();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmInventory f7 = new frmInventory();
            f7.ShowDialog();
            this.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            CrystalReports.crptProducts products = new CrystalReports.crptProducts();
            products.SetDatabaseLogon("group2fa202330", "1867186");
            this.Hide();
            frmPrint f3 = new frmPrint();
            f3.crvViewer.ReportSource = null;
            f3.crvViewer.ReportSource = products;
            f3.ShowDialog();
            this.Show();
        }

        private void frmInfo_Load(object sender, EventArgs e)
        {
            ProgOps.OpenDatabase();
            ProgOps.DatabaseDGVCommand(dgvDatabase);
        }

        private void frmInfo_FormClosing(object sender, FormClosingEventArgs e)
        {
            ProgOps.CloseDatabase();
        }
    }
}
