﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmCalculator : Form
    {
        string operation;
        double N_1;

        public frmCalculator()
        {
            InitializeComponent();
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            //CLEAR BUTTON....FORGOT TO RENAME
            lblShow.Text = "0";
            add_clicked = false;
            subtract_clicked = false;
            multiply_clicked = false;
            divide_clicked = false;
            number_of_clicks = 0;
        }

        private void Btn_1_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "1";
            }
            else
            {
                lblShow.Text = lblShow.Text + "1";
            }
        }

        private void Btn_2_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "2";
            }
            else
            {
                lblShow.Text = lblShow.Text + "2";
            }
        }

        private void Btn_3_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "3";
            }
            else
            {
                lblShow.Text = lblShow.Text + "3";
            }
        }

        private void Btn_4_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "4";
            }
            else
            {
                lblShow.Text = lblShow.Text + "4";
            }
        }

        private void Btn_5_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "5";
            }
            else
            {
                lblShow.Text = lblShow.Text + "5";
            }
        }

        private void Btn_6_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "6";
            }
            else
            {
                lblShow.Text = lblShow.Text + "6";
            }
        }

        private void Btn_7_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "7";
            }
            else
            {
                lblShow.Text = lblShow.Text + "7";
            }
        }

        private void Btn_8_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "8";
            }
            else
            {
                lblShow.Text = lblShow.Text + "8";
            }
        }

        private void Btn_9_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "9";
            }
            else
            {
                lblShow.Text = lblShow.Text + "9";
            }
        }

        private void Btn_0_Click(object sender, EventArgs e)
        {
            if (lblShow.Text == "0")
            {
                lblShow.Text = "";
                lblShow.Text = "0";
            }
            else
            {
                lblShow.Text = lblShow.Text + "0";
            }
        }

        int max_decimal = 0;

        private void btnPoint_Click(object sender, EventArgs e)
        {
            if (max_decimal == 0)
            {
                lblShow.Text = lblShow.Text + ".";
            }
            max_decimal = 1;
        }

        bool add_clicked = false;

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            N_1 = Convert.ToDouble(lblShow.Text);
            lblShow.Text = "0";
            operation = "+";
            add_clicked = true;
            max_decimal = 0;
            negative = 0;
        }

        bool subtract_clicked = false;
        private void BtnSubtract_Click(object sender, EventArgs e)
        {
            N_1 = Convert.ToDouble(lblShow.Text);
            lblShow.Text = "0";
            operation = "-";
            subtract_clicked = true;
            max_decimal = 0;
            negative = 0;
        }

        bool multiply_clicked = false;

        private void BtnMultiply_Click(object sender, EventArgs e)
        {
            N_1 = Convert.ToDouble(lblShow.Text);
            lblShow.Text = "0";
            operation = "*";
            multiply_clicked = true;
            max_decimal = 0;
            negative = 0;
        }

        bool divide_clicked = false;
        private void BtnDivide_Click(object sender, EventArgs e)
        {
            N_1 = Convert.ToDouble(lblShow.Text);
            lblShow.Text = "0";
            operation = "/";
            divide_clicked = true;
            max_decimal = 0;
            negative = 0;
        }

        int negative = 0;

        private void BtnOpposite_Click(object sender, EventArgs e)
        {
            if (negative == 0)
            {
                lblShow.Text = "-" + lblShow.Text;
            }

            negative = 1;
        }
        double result = 0;
        int number_of_clicks = 0;
        double repeat_number = 0;

        private void BtnEquals_Click(object sender, EventArgs e)
        {
            double N_2 = 0;


            max_decimal = 0;
            negative = 0;

            if (number_of_clicks == 0)
            {

                N_2 = Convert.ToDouble(lblShow.Text);
                repeat_number = N_2;
            }
            else
            {
                N_2 = repeat_number;
            }


            if (operation == "+" && add_clicked == true)
            {
                if (number_of_clicks == 0)
                {
                    result = N_1 + N_2;
                    lblShow.Text = Convert.ToString(result);
                    number_of_clicks += 1;
                }
                else if (number_of_clicks > 0)
                {
                    result += N_2;
                    lblShow.Text = Convert.ToString(result);
                }
            }
            if (operation == "-" && subtract_clicked == true)
            {
                if (number_of_clicks == 0)
                {
                    result = N_1 - N_2;
                    lblShow.Text = Convert.ToString(result);
                    number_of_clicks += 1;
                }
                else if (number_of_clicks > 0)
                {
                    result -= N_2;
                    lblShow.Text = Convert.ToString(result);
                }
            }
            if (operation == "*" && multiply_clicked == true)
            {
                if (number_of_clicks == 0)
                {
                    result = N_1 * N_2;
                    lblShow.Text = Convert.ToString(result);
                    number_of_clicks += 1;
                }
                else if (number_of_clicks > 0)
                {
                    result = result * N_2;
                    lblShow.Text = Convert.ToString(result);
                }
            }

            try
            {
                if (operation == "/" && divide_clicked == true)
                {
                    if (N_2 == 0)
                        throw new DivideByZeroException();

                    if (number_of_clicks == 0)
                    {
                        result = N_1 / N_2;
                        lblShow.Text = Convert.ToString(result);
                        number_of_clicks += 1;
                    }
                    else if (number_of_clicks > 0)
                    {
                        result = result / N_2;
                        lblShow.Text = Convert.ToString(result);
                    }
                }
            }
            catch (DivideByZeroException Z)
            {
                MessageBox.Show(Z.Message);
            }
        }
    }
}
