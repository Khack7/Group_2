﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Media;
using Microsoft.VisualBasic;

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmOrders : Form
    {
        string myState;//<- I DON'T THINK THIS IS NEEDED
        int myBookmark;

        public frmOrders()
        {
            InitializeComponent();
        }

        CurrencyManager ordersManager;

        private void btnCalculator_Click(object sender, EventArgs e)
        {
            frmCalculator f8 = new frmCalculator();
            f8.ShowDialog();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmOrders_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseOrdersTBXCommand(tbxOrderID, tbxOrderAmount, tbxEmployeeID, tbxCustomerID, tbxSupplierID);
            ordersManager = (CurrencyManager)BindingContext[ProgOps.DTOrdersTable];
            SetState("Veiw");
        }

        private void frmOrders_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (myState.Equals("Edit") || myState.Equals("Add"))
            {
                MessageBox.Show("You must finish the current edit before stopping the application.", "Finish Edit!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = true;
            }
            else
            {
                ProgOps.UpdateOrdersTBXOnClose();
            }
        }

        private void SetState(string appState)
        {
            switch (appState)
            {
                case "Veiw":
                    tbxOrderID.ReadOnly = true;
                    tbxOrderAmount.ReadOnly = true;
                    tbxEmployeeID.ReadOnly = true;
                    tbxCustomerID.ReadOnly = true;
                    tbxSupplierID.ReadOnly = true;
                    btnPrev.Enabled = true;
                    btnNext.Enabled = true;
                    btnFirst.Enabled = true;
                    btnLast.Enabled = true;
                    btnAdd.Enabled = true;
                    btnSave.Enabled = false;
                    btnCancel.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnCalculator.Enabled = true;
                    btnBack.Enabled = true;
                    tbxOrderID.Focus();
                    break;
                case "Add":
                    tbxOrderID.ReadOnly = false;
                    tbxOrderAmount.ReadOnly = false;
                    tbxEmployeeID.ReadOnly = false;
                    tbxCustomerID.ReadOnly = false;
                    tbxSupplierID.ReadOnly = false;
                    btnPrev.Enabled = false;
                    btnNext.Enabled = false;
                    btnFirst.Enabled = false;
                    btnLast.Enabled = false;
                    btnAdd.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnCalculator.Enabled = false;
                    btnBack.Enabled = false;
                    tbxOrderID.Focus();
                    break;
                case "Edit":
                    tbxOrderID.ReadOnly = false;
                    tbxOrderAmount.ReadOnly = false;
                    tbxEmployeeID.ReadOnly = false;
                    tbxCustomerID.ReadOnly = false;
                    tbxSupplierID.ReadOnly = false;
                    btnPrev.Enabled = false;
                    btnNext.Enabled = false;
                    btnFirst.Enabled = false;
                    btnLast.Enabled = false;
                    btnAdd.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnCalculator.Enabled = false;
                    btnBack.Enabled = false;
                    tbxOrderID.Focus();
                    break;
            }
            myState = appState;//<- I DON'T THINK THIS IS NEEDED OR THE STRING myState INITIALIZED AT THE TOP
            tbxOrderID.Focus();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            ordersManager.Position = 0;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            ordersManager.Position--;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            ordersManager.Position++;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            ordersManager.Position = ordersManager.Count - 1;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            int password; //<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            bool accepted = Int32.TryParse(Interaction.InputBox("Password required to make alterations", "Input Password", ""), out password);

            if (accepted && password == 94261)//<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            {
                SetState("Edit");
            }
            else
            {
                MessageBox.Show("INVALID PASSWORD", "UNACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SetState("View");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int password; //<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            bool accepted = Int32.TryParse(Interaction.InputBox("Password required to make alterations", "Input Password", ""), out password);

            if (accepted && password == 94261)//<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            {
                myBookmark = ordersManager.Position;
                SetState("Add");
                ordersManager.AddNew();
            }
            else
            {
                MessageBox.Show("INVALID PASSWORD", "UNACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SetState("View");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ordersManager.CancelCurrentEdit();
            if (myState.Equals("Add"))
            {
                ordersManager.Position = myBookmark;
            }
            MessageBox.Show("The record was saved!", "Save");
            SetState("Veiw");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            ordersManager.EndCurrentEdit();
            ProgOps.DTOrdersTable.DefaultView.Sort = "OrderID";
            MessageBox.Show("The record was saved!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            SetState("Veiw");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult response;
            response = MessageBox.Show("Are you sure you want to delete?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (response == DialogResult.Yes)
            {
                ordersManager.RemoveAt(ordersManager.Position);
            }
            SetState("Veiw");
        }
    }
}
