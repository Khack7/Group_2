﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Programers: Miriam Lira, Chris Howell, Kevin Hack
// Instructor: Kathryn Wilganowski
// Project: M.C.K. Inventory Managment Software
// Course: Comp Software Proj: Plan/Desig (INEW-2330-50Z1)

namespace M.C.K.Inventory_Management_Software
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            ProgOps.OpenDatabase();
            hlpUser.HelpNamespace = Application.StartupPath + "\\Help.chm";
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Your password is your employee ID number", "Hint", MessageBoxButtons.OK);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtLogin.Text = "";
            txtLogin.Focus();
        }
            
        private void txtLogin_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
            txtLogin.MaxLength = 10;
        }

        private void btnPassShow_Click(object sender, EventArgs e)
        {
            string TextOnButton = btnPassShow.Text;

            switch(TextOnButton)
            {
                case "Show":
                    txtLogin.PasswordChar = '\0';
                    btnPassShow.Text = "Hide";
                    break;
                case "Hide":
                    txtLogin.PasswordChar = '•';
                    btnPassShow.Text = "Show";
                    break;
            }
        }

        private void mnuAbout_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmAbout about = new frmAbout();
            about.Show();
            this.Show();
        }

        private void mnuHelp_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, hlpUser.HelpNamespace);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Hide();

            bool AcceptedPassword = false;

            List<string> passwords = new List<string>();
            passwords.Add("2424242424"); // Miriam Lira
            passwords.Add("2020002008"); // Chris Howell
            passwords.Add("4206900008"); // Kevin Hack
            passwords.Add("0123456789"); // Mrs. Wilganowski
            passwords.Add("5772109984"); // Test User

            frmInfo info = new frmInfo();

            if (passwords.Contains(txtLogin.Text))
            {
                txtLogin.Text = "";
                txtLogin.Focus();
                string TextOnButton = btnPassShow.Text;

                switch (TextOnButton)
                {
                    case "Hide":
                        txtLogin.PasswordChar = '•';
                        btnPassShow.Text = "Show";
                        break;
                }

                info.ShowDialog();
                AcceptedPassword = true;

            }
            if (AcceptedPassword == false)
            {
                MessageBox.Show("INVALID PASSWORD", "ATTENTION", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLogin.Text = "";
                txtLogin.Focus();
            }

            this.Show();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            ProgOps.CloseDatabase();
        }
    }
}
