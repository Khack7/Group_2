﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.VisualBasic;

namespace M.C.K.Inventory_Management_Software
{
    public partial class Form7 : Form
    {
        string myState;//<- I DON'T THINK THIS IS NEEDED
        int myBookmark;

        public Form7()
        {
            InitializeComponent();
        }

        CurrencyManager ordersProductsManager;

        private void btnCalculator_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f8 = new Form8();
            f8.ShowDialog();
            this.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            ProgOps.DatabaseTBXCommand(textBox1, textBox2, textBox3, textBox4, textBox5, textBox9, textBox8, textBox7);
            ordersProductsManager = (CurrencyManager)BindingContext[ProgOps.DTDatabaseTable];
            SetState("Veiw");
        }

        private void Form7_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (myState.Equals("Edit") || myState.Equals("Add"))
            {
                MessageBox.Show("You must finish the current edit before stopping the application.", "Finish Edit!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                e.Cancel = true;
            }
            else
            {
                ProgOps.UpdateTBXOnClose();
            }
        }

        private void SetState(string appState)
        {
            myState = appState;//<- I DON'T THINK THIS IS NEEDED OR THE STRING myState INITIALIZED AT THE TOP
            switch (appState)
            {
                case "Veiw":
                    textBox1.ReadOnly = true;
                    textBox2.ReadOnly = true;
                    textBox3.ReadOnly = true;
                    textBox4.ReadOnly = true;
                    textBox5.ReadOnly = true;
                    textBox9.ReadOnly = true;
                    textBox8.ReadOnly = true;
                    textBox7.ReadOnly = true;
                    btnPrev.Enabled = true;
                    btnNext.Enabled = true;
                    btnFirst.Enabled = true;
                    btnLast.Enabled = true;
                    btnAdd.Enabled = true;
                    btnSave.Enabled = false;
                    btnCancel.Enabled = false;
                    btnEdit.Enabled = true;
                    btnDelete.Enabled = true;
                    btnCalculator.Enabled = true;
                    btnBack.Enabled = true;
                    textBox1.Focus();
                    break;
                case "Add":
                    textBox1.ReadOnly = false;
                    textBox2.ReadOnly = false;
                    textBox3.ReadOnly = false;
                    textBox4.ReadOnly = false;
                    textBox5.ReadOnly = false;
                    textBox9.ReadOnly = false;
                    textBox8.ReadOnly = false;
                    textBox7.ReadOnly = false;
                    btnPrev.Enabled = false;
                    btnNext.Enabled = false;
                    btnFirst.Enabled = false;
                    btnLast.Enabled = false;
                    btnAdd.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnCalculator.Enabled = false;
                    btnBack.Enabled = false;
                    textBox1.Focus();
                    break;
                case "Edit":
                    textBox1.ReadOnly = false;
                    textBox2.ReadOnly = false;
                    textBox3.ReadOnly = false;
                    textBox4.ReadOnly = false;
                    textBox5.ReadOnly = false;
                    textBox9.ReadOnly = false;
                    textBox8.ReadOnly = false;
                    textBox7.ReadOnly = false;
                    btnPrev.Enabled = false;
                    btnNext.Enabled = false;
                    btnFirst.Enabled = false;
                    btnLast.Enabled = false;
                    btnAdd.Enabled = false;
                    btnSave.Enabled = true;
                    btnCancel.Enabled = true;
                    btnEdit.Enabled = false;
                    btnDelete.Enabled = false;
                    btnCalculator.Enabled = false;
                    btnBack.Enabled = false;
                    textBox1.Focus();
                    break;
            }
            textBox1.Focus();
        }

        private void BtnEdit_Click(object sender, EventArgs e)
        {
            int password; //<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            bool accepted = Int32.TryParse(Interaction.InputBox("Password required to make alterations", "Input Password", ""), out password);

            if (accepted && password == 94261)//<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            {
                SetState("Edit");
            }
            else
            {
                MessageBox.Show("INVALID PASSWORD", "UNACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SetState("View");
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            int password; //<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            bool accepted = Int32.TryParse(Interaction.InputBox("Password required to make alterations", "Input Password", ""), out password);

            if (accepted && password == 94261)//<-FEEL FREE TO MAKE THIS WHATEVER YOU WANT
            {
                myBookmark = ordersProductsManager.Position;
                SetState("Add");
                ordersProductsManager.AddNew();
            }
            else
            {
                MessageBox.Show("INVALID PASSWORD", "UNACCEPTED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                SetState("View");
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            ordersProductsManager.EndCurrentEdit();
            ProgOps.DTProductsTable.DefaultView.Sort = "ProductID"; // <-UNSURE IF CORRECT
            MessageBox.Show("The record was saved!", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
            SetState("Veiw");
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            DialogResult response;
            response = MessageBox.Show("Are you sure you want to delete?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (response == DialogResult.Yes)
            {
                ordersProductsManager.RemoveAt(ordersProductsManager.Position);
            }
            SetState("Veiw");
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            ordersProductsManager.CancelCurrentEdit();
            if (myState.Equals("Add"))
            {
                ordersProductsManager.Position = myBookmark;
            }
            MessageBox.Show("The record was saved!", "Save");
            SetState("Veiw");
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            ordersProductsManager.Position = 0;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            ordersProductsManager.Position = ordersProductsManager.Count - 1;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            ordersProductsManager.Position++;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            ordersProductsManager.Position--;
        }
    }
}
