﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M.C.K.Inventory_Management_Software
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        decimal answer;

        private decimal Add(decimal a, decimal b)
        {
            answer = a + b;
            return answer;
        }

        private decimal Subtract(decimal a, decimal b)
        {
            answer = a - b;
            return answer;
        }

        private decimal Multiply(decimal a, decimal b)
        {
            answer = a * b;
            return answer;
        }

        private decimal Divide(decimal a, decimal b)
        {
            answer = a / b;
            return answer;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            decimal firstNumber;
            decimal secondNumber;
            firstNumber = decimal.Parse(textBox1.Text);
            secondNumber = decimal.Parse(textBox2.Text);
            Add(firstNumber, secondNumber);
            label3.Text = answer.ToString("n2");
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            decimal firstNumber;
            decimal secondNumber;
            firstNumber = decimal.Parse(textBox1.Text);
            secondNumber = decimal.Parse(textBox2.Text);
            Subtract(firstNumber, secondNumber);
            label3.Text = answer.ToString("n2");
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            decimal firstNumber;
            decimal secondNumber;
            firstNumber = decimal.Parse(textBox1.Text);
            secondNumber = decimal.Parse(textBox2.Text);
            Multiply(firstNumber, secondNumber);
            label3.Text = answer.ToString("n2");
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            decimal firstNumber;
            decimal secondNumber;
            firstNumber = decimal.Parse(textBox1.Text);
            secondNumber = decimal.Parse(textBox2.Text);
            Divide(firstNumber, secondNumber);
            label3.Text = answer.ToString("n2");
        }
    }
}
